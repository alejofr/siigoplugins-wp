<?php 
    $Object = new DateTime();
    $Object->setTimezone(new DateTimeZone('America/Caracas'));

?>
<?php 
            define('PREFIJO', 'wpxs_');
			define( 'DB_NAME', 'work_wp242' );
			define( 'DB_USER', 'work_wp242' );
			define( 'DB_PASSWORD', 'p3S]x7Fd5.');
			define( 'DB_HOST', 'localhost' );?>
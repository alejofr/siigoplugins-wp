<?php 

    $jobs_pedidos = [];
    $tipo = 'pedidos';
    $mensaje = "";

    if(ejecutarSQL::check_table('sg_pedidos_jobs')){
        $consultas = ejecutarSQL::consultar("select * from sg_pedidos_jobs");
        $jobs_pedidos = mysqli_fetch_all($consultas);
    }else{
        ejecutarSQL::create_sg_pedidos_jobs_table();
    }

    if ( isset($_POST['fecha_c']) ) {

        if ( $_POST['fecha_c'] != '' ){

            $consultar = ejecutarSQL::consultar("select * from sg_configuracion_jobs where tipo='".$tipo."'");
            $fecha = $Object->format("Y-m-d h:i:s a");
    
            $setting['fecha_c'] = $_POST['fecha_c'];
            $setting = json_encode($setting);
    
    
            if (mysqli_num_rows($consultar) != 0){
                consultasSQL::UpdateSQL('sg_configuracion_jobs', "
                    setting = '".$setting."',
                    fecha_editado = '".$fecha."'
                ", 'tipo="pedidos"');
    
                $mensaje = "Configuacion Actualizada";
            }else{ 
                consultasSQL::InsertSQL('sg_configuracion_jobs', 'tipo,	setting,fecha_creado,fecha_editado', "
                    '$tipo',
                    '$setting',
                    '$fecha',
                    '$fecha'
                ");
    
                $mensaje = "Configuacion agregada";
                
            }
            
            $class = 'updated';

        }else{
            $mensaje = "Debe completar el formulario";
            $class = 'error';
        }
    }

    $consultar = ejecutarSQL::consultar("select * from sg_configuracion_jobs where tipo='".$tipo."'");


    if (mysqli_num_rows($consultar) != 0){
        $configuracion = mysqli_fetch_array($consultar);
        $aux = "";
        foreach ($configuracion as $key => $value) {
            if ( $key == 'setting' ){
                $aux = json_decode($configuracion[$key]);
            }
        }
        $configuracion = $aux;
    }

?>

<div class="table100 ver1 m-b-110">
    <div class="table100-head">
        <table>
            <thead>
                <tr class="row100 head">
                    <th class="cell100 column1">Orden Id</th>
                    <th class="cell100 column2">Cliente Identidad</th>
                    <th class="cell100 column3">Total</th>
                    <th class="cell100 column4">Fecha</th>
                </tr>
            </thead>
        </table>
    </div>

    <div class="table100-body js-pscroll">
        <table>
            <tbody>
            <?php
                if( count($jobs_pedidos) != 0 ){ 
                    for ($i=0; $i < count($jobs_pedidos); $i++) {  
                        $ident = json_decode($jobs_pedidos[$i][2]);
                             
                ?>
                    <tr class="row100 body">
                        <td class="cell100 column1"><?php  echo $jobs_pedidos[$i][0]; ?></td>
                        <td class="cell100 column2"><?php  echo $ident->identification ?></td>
                        <td class="cell100 column3"><?php  echo $jobs_pedidos[$i][4]; ?></td>
                        <td class="cell100 column4"><?php  echo $jobs_pedidos[$i][5] ?></td>
                    </tr>
                <?php 
                    }//for
                }//cierre if
                ?>
            </tbody>
        </table>
    </div>
</div>
<?php  if( $mensaje != "" ) { ?>
        <div id="message"  class="<?php echo $class; ?> notice is-dismissible" style="margin: 15px 0 15px 0;">
            <p><?php echo $mensaje; ?></p>
            <button type="button" class="notice-dismiss close_div_message" onclick="closeMensaje(event)">
                <span class="screen-reader-text"> Descartar Este Aviso </span>
            </button>
        </div>
        <?php } ?>
<div property="content" typeof="Item"style="grid-template-columns: 1.5fr 2fr;">
    <div>
        <h3 property="headline" aria-label="Headline" class="">Configuración Pedidos</h3>
        <p property="text" aria-label="Text" class="">
             Es Importante agregar el parametro de fecha de aranque.
            <br>
        </p>
    </div>
    <div>
        <form action="<?php echo $_SERVER['REQUEST_URI'] ?>" class="__form_sg_api" method="POST" style="max-width: 380px;margin:0 auto;" >
            <div class="group_input">
                <label for="one" class="form-label">Fecha de Comienzo.</label>
                <input type="date" class="form-control input_style_0" name="fecha_c" <?php if( isset($configuracion) && $configuracion->fecha_c != '' ) { ?> disabled value="<?php echo $configuracion->fecha_c; ?>" <?php } ?> id="one" >
            </div>
            <button type="submit" class="btn-submit-table" style="margin-top: 10px;cursor:pointer;">
                <span property="destination" aria-label="Destination" class="">Guardar</span>
            </button>
        </form>
    </div>
</div>